from qam_modem import QAMModem
import numpy as np

def test_modulation_demotion():
    modem = QAMModem(16, use_gray=True)
    bits = np.random.randint(0, 2, 1000)
    symbols = modem.modulate(bits)
    recovered_bits = modem.demodulate(symbols)
    assert bits.tolist()[:len(recovered_bits)] == recovered_bits
